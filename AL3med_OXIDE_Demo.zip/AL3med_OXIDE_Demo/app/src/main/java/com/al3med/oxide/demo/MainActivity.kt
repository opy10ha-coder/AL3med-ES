package com.al3med.oxide.demo

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(12, 12, 15))
        }
        val title = TextView(this).apply {
            text = "AL3med OXIDE\nDEMO OVERLAY"
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 24)
        }
        val info = TextView(this).apply {
            text = "أهداف افتراضية للتجربة فقط"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, 24)
        }
        val permission = Button(this).apply {
            text = "السماح بالواجهة العائمة"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        }
        val start = Button(this).apply {
            text = "تشغيل العرض التجريبي"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java).setAction("START"))
                } else {
                    permission.performClick()
                }
            }
        }
        val stop = Button(this).apply {
            text = "إيقاف العرض التجريبي"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(permission)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }
}
