package com.al3med.oxide.demo

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import kotlin.math.sin

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: TargetView? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlay != null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (android.os.Build.VERSION.SDK_INT >= 26)
            LayoutParams.TYPE_APPLICATION_OVERLAY else LayoutParams.TYPE_PHONE
        val params = LayoutParams(
            LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, type,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_NOT_TOUCHABLE or
                LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        overlay = TargetView()
        wm.addView(overlay, params)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private inner class TargetView : View(this@OverlayService) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var phase = 0f

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            // Targets are generated locally and are not sourced from any game.
            val w = width.toFloat()
            val h = height.toFloat()
            paint.color = Color.argb(210, 0, 230, 180)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3.5f
            for (i in 0..2) {
                val x = w * (0.25f + i * 0.25f) + sin(phase + i) * 35f
                val y = h * (0.35f + (i % 2) * 0.18f)
                canvas.drawCircle(x, y, 34f, paint)
                canvas.drawRect(x - 24, y - 42, x + 24, y + 42, paint)
                paint.style = Paint.Style.FILL
                paint.textSize = 28f
                canvas.drawText("DEMO ${i + 1}", x - 38, y - 52, paint)
                paint.style = Paint.Style.STROKE
            }
            // Central practice reticle
            paint.color = Color.WHITE
            canvas.drawCircle(w / 2, h / 2, 24f, paint)
            canvas.drawLine(w / 2 - 38, h / 2, w / 2 + 38, h / 2, paint)
            canvas.drawLine(w / 2, h / 2 - 38, w / 2, h / 2 + 38, paint)
            phase += 0.035f
            postInvalidateDelayed(33)
        }
    }
}
