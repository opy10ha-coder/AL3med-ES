plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.al3med.oxide.demo"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.al3med.oxide.demo"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
